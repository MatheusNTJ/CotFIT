<?php

require once 'model/Projeto.php';

class Projetocontroller
{
    public function all(){

        $obj = new Projeto();
        $projetos - $obj->all();

        require_once 'view/Projeto_all.php';
        
        }
}
    public function create(){

        $obj = new Projeto();
        if( isset($_POST['nome']) )
        {
            $obj->setNome($_POST['nome']);
            $obj->setDuracao ($ POST['duracao']);
            $obj->create();
            $projeto = Şobj->read();
        }

        else{
            $projeto = (object)
        }

    }